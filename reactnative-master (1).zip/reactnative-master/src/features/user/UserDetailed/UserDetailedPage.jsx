import React from 'react'

const UserDetailedPage = () => {
    return (
        <div>
            <h1>User Detailed Page</h1>
        </div>
    )
}

export default UserDetailedPage
