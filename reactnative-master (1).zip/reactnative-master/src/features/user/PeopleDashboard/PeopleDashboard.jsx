import React from 'react'

const PeopleDashboard = () => {
    return (
        <div>
            <h1>People dashboard</h1>
        </div>
    )
}

export default PeopleDashboard
