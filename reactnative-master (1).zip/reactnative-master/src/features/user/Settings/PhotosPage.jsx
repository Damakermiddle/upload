import React from 'react'

const PhotosPage = () => {
    return (
        <div>
            <h1>Photos Page</h1>
        </div>
    )
}

export default PhotosPage
